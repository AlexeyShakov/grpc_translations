from . import translation_pb2, translation_pb2_grpc
# import translation_pb2
# import translation_pb2_grpc
